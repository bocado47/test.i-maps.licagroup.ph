<?php
$CI =& get_instance();
$CI->load->model('Report_m');
$session_data = $CI->session->userdata('logged_in');
$datas=$session_data[0];
$type=$datas->type;
$id=$datas->id;
if($type == 1)
{
	$brand=$CI->Report_m->Brands();
}else{
	$brand=$CI->Report_m->Brands2($id);
}

?>
<style type="text/css">
	a.disabled {
   pointer-events: none;
   cursor: default;
}
</style>
<main role="main" class="col-md-9 ml-sm-auto col-lg-10 pt-3 px-4">
	<h1>Reports</h1>
	<br/>
	<!--  -->
	<div class="col">
		<div class="form-group row">
				<div class="col-sm-4">
					<div class="card" style="width: 24rem; ">
						<div class="card-header">
					    	<h4 class="card-title">View Daily Inventory Report</h4>
						</div>
					  <div class="card-body">
					  	<h5 class="card-title">Select Dealer:</h5>
					    <p class="card-text">
					    	<select class="form-control" id="dealer">
					    		<option value="">SELECT DEALER</option>
					    		<?php foreach($brand as $value) { ?> 
					    		<option value="<?php echo $value->Company; ?>"><?php echo $value->Company; ?></option>
					    		<?php } ?>
					    	</select>
					    </p>
					    <a href="#" class="btn btn-primary disabled" id="viewreport" style="float:right;" value="#">View Report</a>
					  </div>
					</div>
				</div>
		</div>
	</div>
</main>
</div>
</div>
<script type="text/javascript">
	$(document).ready(function() {
		var bUrl="<?php echo base_url(); ?>";
		$('select').select2();
		$('#dealer').on('change',function(){
			 $value=$(this).val();
			 
			 // $vrval=$('#viewreport').val($value);

			 if($value == "")
			 {
			 	$('#viewreport').addClass("disabled");
			 	$("#viewreport").attr("href", "#");
			 }else{
			 	$('#viewreport').removeClass("disabled");
			 	$("#viewreport").attr("href", bUrl+"Report/VDIR?dealer="+$value);
			 }
			 
		});
	});
</script>