<html>
<head>
      <!-- <link href="<?php echo base_url(); ?>assets/bootstrap-4.2.1-dist/css/bootstrap.min.css" rel="stylesheet"> -->
      <!-- <link href="<?php echo base_url(); ?>assets/css/signin.css" rel="stylesheet"> -->
     
      <!-- JS -->
      <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery-3.3.1.min.js"></script>
      <!-- <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script> -->
  
      <script type="text/javascript" src="<?php echo base_url(); ?>assets/bootstrap-4.2.1-dist/js/bootstrap.min.js"></script>
     
<style type="text/css">/* Chart.js */
	table {
	  border-collapse: collapse;
	}

	table, th, td {
	  border: 1px solid black;
	  text-align: center;
	}
	@media print {
	  #print {
	    display: none;
	  }
	}
	.button {
	  background-color: #4CAF50; /* Green */
	  border: none;
	  color: white;
	  padding: 15px 32px;
	  text-align: center;
	  text-decoration: none;
	  display: inline-block;
	  font-size: 16px;
	}
	.button2 {
	  background-color: red; /* Green */
	  border: none;
	  color: white;
	  padding: 15px 32px;
	  text-align: center;
	  text-decoration: none;
	  display: inline-block;
	  font-size: 16px;
	}
</style>
	</head>
<body style="z-index:1px;">
<div>
	<button id="close" class="button2" style="float:right;padding: 10px; margin:10px; ">Close</button>
	<button id="print" class="button" style="float:right;padding: 10px; margin:10px;">Print</button>
	<h2 style="text-align: center;">TEAM <?php echo $dealer; ?>  VIEW DAILY INVENTORY REPORT</h2>
	<table style="width:100%;">
		<thead></thead>
		<tbody>
			<?php foreach($report as $value) { 
				$info=$value['Info'];
				$count=0;
			?>
			<tr>
				<td colspan="9"><h3><?php echo $value['Model']; ?></h3></td>
			</tr>
			<tr>
				<td>CS NUM</td>
				<td>COLOR</td>
				<td>YEAR</td>
				<td>PO DATE</td>
				<td>RECEIVED DATE</td>
				<td>PO NUM</td>
				<td>VIN NUM</td>
				<td>LOCATION</td>
				<td>VRR NUM</td>
			</tr>
			<?php foreach($info as $val){ 
				$count++;
			?> 
				<tr>
					<td><?php echo $val['cs_num']; ?></td>
					<td><?php echo $val['color']; ?></td>
					<td><?php echo $val['dlr']; ?></td>
					<td><?php echo $val['mth_d_f_o']; ?></td>
					<td><?php echo $val['received']; ?></td>
					<td><?php echo $val['po_num']; ?></td>
					<td><?php echo $val['vin']; ?></td>
					<td><?php echo $val['loc']; ?></td>
					<td><?php echo $val['vrr_no']; ?></td>
				</tr>
				<?php } ?>
				<tr>
					<td colspan="8" style="text-align: right !important;">
						Available <?php echo $value['Model']; ?> :
					</td>
					<td><?php echo $count; ?></td>
				</tr>
			<?php } ?>
		</tbody>
	</table>
</div> 
</body>
</html>
<script type="text/javascript">
	$(document).ready(function() {
		var bUrl="<?php echo base_url(); ?>";
		$("#print").on('click',function(){
			window.print();
		});
		$('#close').on('click',function(){
		   window.location.href=bUrl+'Report/Dashboard';
		});
	});
</script>